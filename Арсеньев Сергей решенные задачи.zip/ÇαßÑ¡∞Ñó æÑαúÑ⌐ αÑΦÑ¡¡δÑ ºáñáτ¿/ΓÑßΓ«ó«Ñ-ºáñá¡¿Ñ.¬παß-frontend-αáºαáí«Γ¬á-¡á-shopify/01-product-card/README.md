# HTML и CSS

## Что нужно сделать?
Напишите валидную разметку в ```index.html```, а после стилизуйте её в ```index.css``` на основе [макета](https://www.figma.com/file/4Dkzt2twTC29rMHRJJPYqw/%D0%9C%D0%B0%D0%BA%D0%B5%D1%82?node-id=0%3A1) (Frame: Products of the week). 

## Что мы хотим проверить?
Ваше умение верстать.

## Примечания
* Именуйте классы по методологии [БЭМ](https://ru.bem.info/methodology/)
* В макете нет мобильной версии, но, если вы её сделаете, это будет плюсом при отборе на курс.

## По любым вопросам пишите в общий чат в телеграме https://t.me/spurITcourse или на почту academy@spur-i-t.com.